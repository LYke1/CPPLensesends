//
//  main.c
//  L02StdIO
//
//  Created by plter on 14-2-21.
//  Copyright (c) 2014年 plter. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // insert code here...
//    printf("Hello, %d\n",100);
    
//    puts("Hello C\n");
    
//    char buf[100];
//    gets(buf);
//    puts(buf);
    
    int a;
    
    scanf("%d",&a);
    
    printf("%d\n",a);
    
    return 0;
}

