//
//  main.c
//  L04Define
//
//  Created by plter on 14-2-24.
//  Copyright (c) 2014年 plter. All rights reserved.
//

#include <stdio.h>

#define MATH_PI 3.14


int main(int argc, const char * argv[])
{

    // insert code here...
    printf("Hello, %f\n",MATH_PI);
    return 0;
}

