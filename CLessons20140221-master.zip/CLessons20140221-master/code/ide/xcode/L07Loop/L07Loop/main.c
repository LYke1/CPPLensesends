//
//  main.c
//  L07Loop
//
//  Created by plter on 14-2-24.
//  Copyright (c) 2014年 plter. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // insert code here...
    
//    for (int a=0; a<100; a++) {
//        printf("Hello %d\n",a);
//    }
    
//    for (int i=0; i<100; printf("%d\n",i++)) {
//        printf(">>>\n");
//    }
    
//    int i=0;
//    while (i<100) {
//        printf("%d\n",i);
//        i++;
//    }
    
    
    int i=0;
    do {
        printf("%d\n",i);
        
        i++;
    } while (i<100);
    
    
    return 0;
}

