//
//  hello.c
//  L13Include
//
//  Created by plter on 14-2-25.
//  Copyright (c) 2014年 plter. All rights reserved.
//

#include <stdio.h>

void sayHello(){
    printf("Hello C\n");
}