//
//  hello.h
//  L13Include
//
//  Created by plter on 14-2-25.
//  Copyright (c) 2014年 plter. All rights reserved.
//

#ifndef L13Include_hello_h
#define L13Include_hello_h

void sayHello();

#endif
