//
//  main.c
//  L13Include
//
//  Created by plter on 14-2-25.
//  Copyright (c) 2014年 plter. All rights reserved.
//

#include <stdio.h>
#include "hello.h"


int main(int argc, const char * argv[])
{
    
    sayHello();

    // insert code here...
//    printf("Hello, World!\n");
    return 0;
}

